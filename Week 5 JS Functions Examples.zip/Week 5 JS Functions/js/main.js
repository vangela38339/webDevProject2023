/*
   THE MAIN PROGRAM HAS YOU MAJOR
   CODE 
*/

// Ask the use to provide the radius
let myRadius = parseFloat(prompt("What is the radius of the circle?"));

// Calculate area
let myDiameter = calculateDiameter(myRadius);
let myArea = calculateArea(myRadius);
let myCirc = calculateCircumference(myRadius);

// Display result
/*
window.alert("ATTENTION! THE DIAMETER IS: " + myDiameter)
document.write("My area is " + myArea);
console.log("My circumference is " + myCirc);
*/
document.getElementById("radiusTxt").textContent += myRadius;
document.getElementById("ans1").textContent = "Diameter: " + myDiameter;
document.getElementById("ans2").textContent = "Area: " + myArea;
document.getElementById("ans3").textContent = "Circumference: " + myCirc;


