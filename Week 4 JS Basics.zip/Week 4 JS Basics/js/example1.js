/*
    Author: John Rodrigues
    Date: 10-3-2023
    Purpose: To demonstrate the basic functionality of JS
*/

// Display Hello World!
// Displays text in a dialog box (pop up)
alert("Hello, world!");
// Displays text in the console (right click, inspect, click on console)
console.log("Hello again, world!");
// Writes the text into the current location of this code.
document.write("<h2>Hello webpage!</h2>");

// Create a variables and constans
let radius;
const PI = 3.1416;

// Ask the user to provide radius
radius = parseFloat(prompt("Enter the radius"));

// Calculate area
let area = radius ** 2 * PI;
            // or Math.pow(radius, 2) * PI;
            // or radius * radius * PI

document.write("The area is " + area); // string concatination