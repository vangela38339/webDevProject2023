document.addEventListener('DOMContentLoaded', function () {
  var info; // create variable

  fetch('https://dummyjson.com/comments/')
    .then(res => res.json())
    .then(data => {
      info = data;
      console.log(info); // Log the data here

      // Update the content of an element with the id "comments"
      var commentsElement = document.getElementById("comments");

      // displaying two comments
      var comment1 = "<p> Hi my username is: " + info.comments[7].user.username + ".  " + info.comments[0].body + "</p>";
      var comment2 = "<p> Hello my username is : " + info.comments[12].user.username + ".  " + info.comments[12].body + "</p>";
      var comment3 = "<p>Hi my username is : " + info.comments[0].user.username + ".  " + info.comments[5].body + "</p>";

      var combinedHTML = comment1 + comment2 + comment3;

      commentsElement.innerHTML = combinedHTML;

    });
});
