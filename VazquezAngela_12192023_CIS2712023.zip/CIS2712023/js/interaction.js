document.addEventListener("DOMContentLoaded", function () {
  const clickVideo = document.getElementById("logo");
  const footerVideo = document.querySelector(".footer-content video");
  const scrollAnimations = document.querySelectorAll(".scroll-animation");

  clickVideo.addEventListener("click", function () {
    window.location.href = "myWebsite.html";
  });

  clickVideo.addEventListener("mouseover", function () {
    this.muted = true;

    this.currentTime = 0;

    this.play();
  });

  footerVideo.addEventListener("mouseover", function () {
    this.muted = true;

    this.currentTime = 0;

    this.play();
  });

  window.addEventListener("scroll", revealOnScroll);

  function revealOnScroll() {
    for (var i = 0; i < scrollAnimations.length; i++) {
      if (isElementInViewport(scrollAnimations[i])) {
        scrollAnimations[i].classList.add("visible");
      }
    }
  }

  function isElementInViewport(el) {
    var rect = el.getBoundingClientRect();
    return (
      rect.top <= window.innerHeight &&
      rect.bottom >= 0 &&
      rect.left <= window.innerWidth &&
      rect.right >= 0
    );
  
  
  }

  revealOnScroll();
});

const images = ["images/old.jpg", "images/image2.jpg", "images/image3.jpg", "images/image4.jpg", "images/image5.jpg"];
let slideshowTimer;
let currentImgPosition = 0;

// Function to show the next image
function nextImage() {
    clearTimeout(slideshowTimer);
    currentImgPosition++;

    // Check if reached the end of the array, reset to the first image
    if (currentImgPosition === images.length) {
        currentImgPosition = 0;
    }

    updateImage();
    startSlideshowTimer();
}

// Function to show the previous image
function prevImage() {
    clearTimeout(slideshowTimer);
    currentImgPosition--;

    // Check if reached the beginning of the array, set to the last image
    if (currentImgPosition < 0) {
        currentImgPosition = images.length - 1;
    }

    updateImage();
    startSlideshowTimer();
}

// Function to update the image source
function updateImage() {
    const imgElement = document.getElementById("timer");
    imgElement.src = images[currentImgPosition];
}

// Function to start the slideshow timer
function startSlideshowTimer() {
    slideshowTimer = setTimeout(() => {
        nextImage();
    }, 3000);
}

// Start the slideshow
startSlideshowTimer();


/*
Function Name: redirectToSignInPage
Purpose: Redirects to the sign-in page.
*/
function redirectToSignInPage() {
  window.location.href = 'signInPage.html';
}

// global variables section 
var signUpForm = document.getElementById("signup");
var signUpUsername = document.getElementById("username");
var signUpPassword = document.getElementById("pass");

// Event listeners for form validation
signUpUsername.addEventListener("input", validateSignUpUsername);
signUpForm.addEventListener("submit", validateSignUpForm);
signUpPassword.addEventListener("input", validateSignUpPassword);
signUpPassword.addEventListener("focus", showSignUpRules);
signUpPassword.addEventListener("blur", hideSignUpRules);

/*
Function Name: validateSignUpForm
Parameters: event
Return Value: None
Purpose: Validates the sign-up form and prevents submission if invalid.
*/
function validateSignUpForm(event) {
    let isFormValid = true;
  
    // Validate username field
    if (!validateSignUpField(signUpUsername, "signUpUserError", 4, "Username must be at least 4 characters.")) {
        isFormValid = false;
    }
  
    // Validate password field
    if (!validateSignUpPassword()) {
        isFormValid = false;
        showSignUpRules();
    }
  
    if (!isFormValid) {
        event.preventDefault();
        document.getElementById("signUpStatus").textContent = "Status: Invalid! Please revisit the requirements.";
    }
  }
  
  /*
  Function Name: validateSignUpField
  Parameters: field, errorId, minLength, errorMessage
  Return Value: Boolean
  Purpose: Validates a form field based on the specified criteria.
  */
  function validateSignUpField(field, errorId, minLength, errorMessage) {
    let size = field.value.length;
    let message = document.getElementById(errorId);
  
    if (size >= minLength) {
        message.textContent = "";
        field.className = "validInput";
        return true;
    } else {
        message.textContent = `Characters: ${size} ${errorMessage}`;
        field.className = "invalidInput";
        return false;
    }
  }
  
  /*
  Function Name: validateSignUpPassword
  Parameters: None
  Return Value: Boolean
  Purpose: Validates the password field given the specified criteria.
  */
  function validateSignUpPassword() {
    let rules = document.querySelectorAll(".signUpRulesList li");
    let isValid = true;
  
    rules.forEach(item => item.className = "validRule");
  
    let size = signUpPassword.value.length;
    let message = document.getElementById("signUpPwError");
  
    // Check password length
    if (size < 5) {
        rules[0].className = "invalidRule";
        isValid = false;
    }
  
    // Check for lowercase letters
    let containsLowerCase = /[a-z]/.test(signUpPassword.value);
    if (!containsLowerCase) {
        rules[1].className = "invalidRule";
        isValid = false;
    }
  
    // Check for uppercase letters
    let containsUpperCase = /[A-Z]/.test(signUpPassword.value);
    if (!containsUpperCase) {
        rules[2].className = "invalidRule";
        isValid = false;
    }
  
    // Check for special characters
    let containsSpecialCharacter = /[!@#$%&*]/.test(signUpPassword.value);
    if (!containsSpecialCharacter) {
        rules[3].className = "invalidRule";
        isValid = false;
    }
  
    if (isValid) {
        signUpPassword.className = "validInput";
    } else {
        signUpPassword.className = "invalidInput";
    }
  
    return isValid;
  }
  
  /*
  Function Name: showSignUpRules
  Parameters: None
  Return Value: None
  Purpose: Displays the sign-up password rules.
  */
  function showSignUpRules() {
    document.getElementById("signUpPwdRules").className = "showItem";
  }
  
  /*
  Function Name: hideSignUpRules
  Parameters: None
  Return Value: None
  Purpose: Hides the sign-up password rules.
  */
  function hideSignUpRules() {
    if (validateSignUpPassword()) {
        document.getElementById("signUpPwdRules").className = "hideItem";
    } else {
        document.getElementById("signUpPwdRules").className = "showItem";
    }
  }
  
  /*
  Function Name: validateSignUpUsername
  Parameters: None
  Return Value: Boolean
  Purpose: Validates the sign-up username given the specified requirements.
  */
  function validateSignUpUsername() {
    let size = signUpUsername.value.length;
    let message = document.getElementById("signUpUserError");
  
    if (size >= 4) {
        message.textContent = "";
        signUpUsername.className = "validInput";
        return true;
    } else {
        message.textContent = `Characters: ${size} Username must be >= 4 characters.`;
        signUpUsername.className = "invalidInput";
        return false;
    }
  }  

/*
  Function Name: validateConfirmPassword
  Parameters: None
  Return Value: Boolean
  Purpose: To validate the confirmed password. 
*/
  document.addEventListener("DOMContentLoaded", function () {

    var confirmPwdInput = document.getElementById("confirm");
    confirmPwdInput.addEventListener("input", validateConfirmPassword);

    function validateConfirmPassword() {
      var passwordInput = document.getElementById("pass");
      var confirmPasswordError = document.getElementById("confirmPasswordError");

      if (confirmPwdInput.value !== passwordInput.value) {
        confirmPasswordError.textContent = "Passwords do not match.";
        confirmPwdInput.className = "invalidInput";
      } else {
        confirmPasswordError.textContent = "";
        confirmPwdInput.className = "validInput";
      }
    }
  });