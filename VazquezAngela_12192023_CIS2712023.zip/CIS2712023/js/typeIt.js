var myRating = jSuites.rating(document.getElementById('rating'), {
  value: 3,
  tooltip: [ 'Very bad', 'Bad', 'Average', 'Good', 'Very good' ],
});

new TypeIt("#faq-section-1", {
    speed: 50,
    waitUntilVisible: true,
      }).go();

new TypeIt("#faq-section-2", {
    speed: 55,
    waitUntilVisible: true,
      }).go();

new TypeIt("#type", {
    speed: 50,
    waitUntilVisible: true,

}).go();

new TypeIt("#load", {
  speed: 70,
  waitUntilVisible: true,

}).go();


  document.querySelector('jsuites-calendar').addEventListener('onchange', function(e) {
      console.log('New value: ' + e.target.value);
  });
  document.querySelector('jsuites-calendar').addEventListener('onclose', function(e) {
      console.log('Calendar is closed');
  });


